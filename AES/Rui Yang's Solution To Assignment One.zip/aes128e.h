/* Implement the following API.
 * You can add your own functions, but don't modify below this line.
 */

/* Under the 16-byte key at k, encrypt the 16-byte plaintext at p and store it at c. */
void aes128e(unsigned char *c, const unsigned char *p, const unsigned char *k);
