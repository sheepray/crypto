package com.example.playground;

import java.util.List;

public class AP_Property_each_time_all_nodes {
	List<AP_Property_oneTime_each_node> list_all_nodes_each_time;
}
