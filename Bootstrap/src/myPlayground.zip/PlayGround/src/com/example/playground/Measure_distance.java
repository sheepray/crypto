package com.example.playground;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Measure_distance extends ActionBarActivity implements SensorEventListener{
	private SensorManager mSensorManager;
	private Sensor mAccelerometer;
	private float gravity[] = new float[3];
	private int max_line = 5;
	private float distance = 0;
	private float previous_speed = 0;
	private long previous_timestamp = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_measure_distance);
		
		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//		mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
		mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
//		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
	}

	
	protected void onResume(){
		super.onResume();
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
	}
	
	protected void onPause(){
		super.onPause();
		mSensorManager.unregisterListener(this);
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.measure_distance, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		if(event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
			if(previous_timestamp == 0){
				previous_timestamp = (long) (event.timestamp - 0.2);
			}
			
			TextView show_gravity = (TextView) findViewById(R.id.measure_distance_textView);
			final float alpha = (float) 0.9;
			gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
			gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
			gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];
			
			Log.d("measure_distance", "x:" + gravity[0] + " y:" + gravity[1] + " z:" + gravity[2]);
			String _temp_string = "";
//			if(max_line >= 1){
//				_temp_string = (String)show_gravity.getText();
//				max_line--;
//				
//			}else{
//				max_line = 5;
//			}
			
			float a = (float) Math.sqrt(gravity[0]*gravity[0]*6 + gravity[1]*gravity[1]*15 + 6*gravity[2]*gravity[2])/(float)3;
//			float a = gravity[1];
//			float a = event.values[1];
			a = ((int)(a*10))/(float)10;
//			if(gravity[1] < 0){
//				a = -a;
//			}
			
			float dt = (event.timestamp - previous_timestamp)/(float)1000000000;
			
			distance += previous_speed*dt + (a*dt*dt)/2;
			if(a == 0){
				previous_speed = 0;
			}else{
				previous_speed += a*dt;
			}
			
			
			//cast values
			previous_speed = ((int)(previous_speed*1000))/(float)1000;
			distance = ((int)(distance*1000))/(float)1000;
			
			_temp_string += gravity[0] + " : " + gravity[1] + " : " + gravity[2];
			_temp_string += "\na:" + a + " Speed" + previous_speed + "distance:" + distance;
//			_temp_string = "distance:" + distance;
			
			previous_timestamp = event.timestamp;
			
//			if(max_line > 0){
//				max_line--;
//			}else{
//				show_gravity.setText(_temp_string);
//				max_line=5;
//			}
			
			show_gravity.setText(_temp_string);
			
		}else if(event.sensor.getType() == Sensor.TYPE_STEP_COUNTER){
			TextView show_gravity = (TextView) findViewById(R.id.measure_distance_textView);
			show_gravity.setText("no. steps:" + event.values[0]);
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}
}
