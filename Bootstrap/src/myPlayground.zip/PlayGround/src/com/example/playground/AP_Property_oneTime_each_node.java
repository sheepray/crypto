package com.example.playground;

public class AP_Property_oneTime_each_node {
	String _BSSID;
	int _level;
	int _valid_time;
	
	public AP_Property_oneTime_each_node(){
		_BSSID = "";
		_level = 0;
		_valid_time = 0;
	}
}
