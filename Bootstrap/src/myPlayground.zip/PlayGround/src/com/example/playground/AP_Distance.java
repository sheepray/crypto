package com.example.playground;

public class AP_Distance {
	String AP_Name;
	long distance;
	
	public AP_Distance(){
		AP_Name="unspecified";
		distance = -1;
	}
}
