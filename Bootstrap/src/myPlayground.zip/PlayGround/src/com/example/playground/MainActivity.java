package com.example.playground;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	class WifiScanReceiver extends BroadcastReceiver {
		public void onReceive(Context c, Intent intent) {
		}
	}

	private SensorManager sensorManager;
	private WifiManager myWifiManager;
	private WifiScanReceiver myWifiScanReceiver;
	private Sensor mSensor;
	TextView list_all_sensors_textView;
	TextView list_wifi_scan_result_textView;
	int double_click_list_sensors = 0;
	int double_click_list_wifi_scan = 0;
	List<AP_Property_multiple_time> all_AP;
	AP_Property_multiple_time son_all_AP;

	public void list_sensors(View view) {
		if (double_click_list_sensors == 0) {
			sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
			List<Sensor> sensor_list = sensorManager
					.getSensorList(Sensor.TYPE_ALL);

			String sensor_list_string = new String("");
			Sensor tempSensor;
			int i;
			for (i = 0; i < sensor_list.size(); i++) {
				tempSensor = sensor_list.get(i);
				sensor_list_string = sensor_list_string + (i + 1) + ":"
						+ tempSensor.getName() + "\n";
			}

			if (i > 0) {
				list_all_sensors_textView = (TextView) findViewById(R.id.list_sensors_testview);
				list_all_sensors_textView.setVisibility(TextView.VISIBLE);
				list_all_sensors_textView.setText(sensor_list_string);
			}
			double_click_list_sensors = 1;
		} else {
			double_click_list_sensors = 0;
			list_all_sensors_textView = (TextView) findViewById(R.id.list_sensors_testview);
			list_all_sensors_textView.setText("");
			list_all_sensors_textView.setVisibility(TextView.INVISIBLE);
		}
	}

	public void show_wifi_scan(View view) {
		if (double_click_list_wifi_scan == 0) {
			myWifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
			registerReceiver(myWifiScanReceiver, new IntentFilter(
					WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
			List<ScanResult> wifi_scan_result = myWifiManager.getScanResults();
			String print_scan_result_string = new String(
					"BSSID + SSID + level\n");
			for (int i = 0; i < wifi_scan_result.size(); i++) {
				print_scan_result_string += (i + 1) + ":"
						+ wifi_scan_result.get(i).BSSID.toString() + " + "
						+ wifi_scan_result.get(i).SSID.toString() + " + "
						+ wifi_scan_result.get(i).level + "\n";
			}

			list_wifi_scan_result_textView = (TextView) findViewById(R.id.list_wifi_scan_result_textView);
			list_wifi_scan_result_textView.setText(print_scan_result_string);
			list_wifi_scan_result_textView.setVisibility(TextView.VISIBLE);
			double_click_list_wifi_scan = 1;
		} else {
			double_click_list_wifi_scan = 0;
			list_wifi_scan_result_textView = (TextView) findViewById(R.id.list_wifi_scan_result_textView);
			list_wifi_scan_result_textView.setText("");
			list_wifi_scan_result_textView.setVisibility(TextView.INVISIBLE);
		}
	}

	public MainActivity() {
		all_AP = new ArrayList<AP_Property_multiple_time>();
		son_all_AP = new AP_Property_multiple_time();
		son_all_AP.list_all_nodes = new ArrayList<AP_Property_each_time_all_nodes>();
	}

	public boolean listAssertFiles(String path) {
		// Log.d("listAssertFiles", "try " + path);
		String[] list_calibrate_folder;
		try {
			list_calibrate_folder = getAssets().list(path);
			if (list_calibrate_folder.length > 0) {
				/* This is a folder, continue */
				// Log.d("listAssertFiles", path + " is a folder");
				for (String file : list_calibrate_folder) {
					if (!listAssertFiles(path + "/" + file)) {
						return false;
					}
				}
			} else {
				/*
				 * This is a file, check whether it is .json file. Yes, then
				 * parse. Skip if not
				 */
				String extension = "";

				int i = path.lastIndexOf('.');
				if (i > 0) {
					extension = path.substring(i + 1);
				}

				// Log.d("listAssertFiles", "Extention:" + extension);

				if (extension.equals("json") == true) {
					/* This is a json file. Parse it. */
					Log.d("listAssertFiles", "Parse " + path);

					parse_json_file(path);

				} else {
					/* Skip */
					// Log.d("listAssertFiles", "Skip " + path);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void print_list(List<AP_Property_oneTime_each_node> list) {
		for (int i = 0; i < list.size(); i++) {
			Log.d("print_list", list.get(i)._BSSID + "+" + list.get(i)._level
					/ list.get(i)._valid_time);
		}
		Log.d("print_list", "******** seperate string *********");
	}

	public String open_file_to_String(String fileName) {
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;

		try {
			if (getAssets().open(fileName) == null) {
				System.out.println("Can't open file!");
				return "failure";
			}
			InputStreamReader jsonInput = new InputStreamReader(getAssets()
					.open(fileName));

			br = new BufferedReader(jsonInput);
			String temp;
			while ((temp = br.readLine()) != null) {
				sb.append(temp);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String my_json_string = sb.toString();
		return my_json_string;
	}

	public void parse_json_file(String fileName) {
		String my_json_string = open_file_to_String(fileName);
		List<AP_Property_oneTime_each_node> _temp_each_m = new ArrayList<AP_Property_oneTime_each_node>();

		/* Parse Json string right now */
		try {

			JSONObject jsonObjMain = new JSONObject(my_json_string);

			// get all measurements;
			for (int i = 0; i < jsonObjMain.length(); i++) {
				String object_name = new String("measurement " + (i + 1));
				JSONObject son_object = jsonObjMain.getJSONObject(object_name);

				// get all ap info
				for (int j = 0; j < son_object.length(); j++) {
					AP_Property_oneTime_each_node _temp_Node = new AP_Property_oneTime_each_node();
					JSONObject grandson_object = son_object.getJSONObject("ap"
							+ (j + 1));
					// Log.d("parse_json", grandson_object.getString("BSSID") +
					// "++" + grandson_object.getInt("level"));
					_temp_Node._BSSID = grandson_object.getString("BSSID");
					_temp_Node._level = grandson_object.getInt("level");

					// check whether _temp_node_m contains the node with the
					// BSSID or not
					int k;
					for (k = 0; k < _temp_each_m.size(); k++) {
						if (_temp_each_m.get(k)._BSSID
								.equals(_temp_Node._BSSID) == true) {
							// do exist
							_temp_each_m.get(k)._valid_time++;
							_temp_each_m.get(k)._level += _temp_Node._level;
							break;
						}
					}

					if (k == _temp_each_m.size()) {
						// don't exist
						_temp_Node._valid_time = 1;
						_temp_each_m.add(_temp_Node);
					}

				}
			}

			// print_list(_temp_each_m);

			// copy it to higher level list
			String parent_folder_name = null;
			// get parent folder name
			File _tempFile = new File(fileName);
			parent_folder_name = _tempFile.getParentFile().getName();
			// copy _temp_each_m to son_all_AP
			// Log.d("parse_json", parent_folder_name);
			if (son_all_AP.list_all_nodes == null
					|| son_all_AP.list_all_nodes.isEmpty() == true) {
				son_all_AP.AP_Name = parent_folder_name;
			}
			AP_Property_each_time_all_nodes grandson_all_AP = new AP_Property_each_time_all_nodes();
			grandson_all_AP.list_all_nodes_each_time = new ArrayList<AP_Property_oneTime_each_node>(
					_temp_each_m);
			son_all_AP.list_all_nodes.add(grandson_all_AP);

			// Log.d("parse_json_file",
			// son_all_AP.list_all_nodes.get(0).list_all_nodes_each_time.get(0)._BSSID
			// + " " + son_all_AP.AP_Name + ":" +
			// son_all_AP.list_all_nodes.size());

			if (son_all_AP.list_all_nodes.size() == 3) {
				// son_all_AP contains 3 directions data right now. just add
				// son_all_AP to all_AP and clean son_all_AP
				AP_Property_multiple_time copy_son_all_AP = new AP_Property_multiple_time();
				copy_son_all_AP.list_all_nodes = new ArrayList<AP_Property_each_time_all_nodes>(
						son_all_AP.list_all_nodes);
				copy_son_all_AP.AP_Name = son_all_AP.AP_Name;
				all_AP.add(copy_son_all_AP);
				son_all_AP.list_all_nodes.clear();
				son_all_AP.AP_Name = "";
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	public void show_all_AP() {
		for (int i = 0; i < all_AP.size(); i++) {
			Log.d("show_all_AP", all_AP.get(i).AP_Name + ":"
					+ all_AP.get(i).list_all_nodes.size());

			// for(int j=0; j<all_AP.get(i).list_all_nodes.size(); j++){
			// }
		}
	}

	public void renew_AP_property(View view) {
		/* find out how many sub-directory that calibration_json_files fold has */
		all_AP.clear();
		Log.d("renew_AP_property", "renew ap properties");
		TextView console_view = (TextView) findViewById(R.id.console_panel);
		console_view.setVisibility(TextView.VISIBLE);
		console_view.setText("Renewing...please wait....");
		listAssertFiles("calibration_json_files");
		console_view.setText("Renew Done");

		// show_all_AP();
	}

	// find the location of on AP with the _BSSID
	public int contains_BSSID(
			List<AP_Property_oneTime_each_node> combined_result, String _BSSID) {
		for (int i = 0; i < combined_result.size(); i++) {
			if (combined_result.get(i)._BSSID.equals(_BSSID) == true) {
				return i;
			}
		}
		return -1;
	}

	public String estimate_location(String file_path, String file_cate)
			throws JSONException {
		TextView list_sensors_testview = (TextView) findViewById(R.id.list_sensors_testview);
		// parse location content
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;
		// String file_path =
		// "random_location2/A150/result_20141105_180149.json";

		try {
			InputStreamReader jsonInput = null;
			if (file_cate.equals("assets")) {
				if (getAssets().open(file_path) == null) {
					System.out.println("Can't open file!");
					return "failure";
				}
				jsonInput = new InputStreamReader(getAssets().open(file_path));
			} else if (file_cate.equals("local.json")) {
				String filePath = getFilesDir() + "/" + file_path;
				File _temp_file = new File(filePath);
				if (!_temp_file.exists()) {
					return "failure: file for local.json don't exsist";
				}
				jsonInput = new InputStreamReader(new FileInputStream(
						_temp_file));
				Log.d("estimate_location", "read from " + filePath);

			}

			br = new BufferedReader(jsonInput);
			String temp;
			int _try_time = 0;
			while ((temp = br.readLine()) != null) {
				_try_time++;
				sb.append(temp);
			}
			if (_try_time == 0) {
				// file is empty
				return "measurement data is empty";
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String my_json_string = sb.toString();

		// list_sensors_testview.setText(my_json_string);

		List<AP_Property_oneTime_each_node> _temp_each_m = new ArrayList<AP_Property_oneTime_each_node>();
		JSONObject jsonObjMain = new JSONObject(my_json_string);

		// list_sensors_testview.setText("size of jsonObjMain=" +
		// jsonObjMain.length());

		// get all measurements;
		for (int i = 0; i < jsonObjMain.length(); i++) {
			String object_name = new String("measurement " + (i + 1));
			JSONObject son_object = jsonObjMain.getJSONObject(object_name);

			// get all ap info
			for (int j = 0; j < son_object.length(); j++) {
				AP_Property_oneTime_each_node _temp_Node = new AP_Property_oneTime_each_node();
				JSONObject grandson_object = son_object.getJSONObject("ap"
						+ (j + 1));
				// Log.d("parse_json", grandson_object.getString("BSSID") + "++"
				// + grandson_object.getInt("level"));
				_temp_Node._BSSID = grandson_object.getString("BSSID");
				_temp_Node._level = grandson_object.getInt("level");

				// check whether _temp_node_m contains the node with the BSSID
				// or not
				int k;
				for (k = 0; k < _temp_each_m.size(); k++) {
					if (_temp_each_m.get(k)._BSSID.equals(_temp_Node._BSSID) == true) {
						// do exist
						_temp_each_m.get(k)._valid_time++;
						_temp_each_m.get(k)._level += _temp_Node._level;
						break;
					}
				}

				if (k == _temp_each_m.size()) {
					// don't exist
					_temp_Node._valid_time = 1;
					_temp_each_m.add(_temp_Node);
				}

			}
		}

		// test code
		// print_list(_temp_each_m);
		// list_sensors_testview.setText("size:" + _temp_each_m.size());

		// estimate location == find the best match
		List<AP_Distance> ap_distance = new ArrayList<AP_Distance>();
		// list_sensors_testview.setText("size of all_AP:" + all_AP.size());
		for (int i = 0; i < all_AP.size(); i++) {
			Log.d("estimate", "analysis no." + i);
			// calculate each AP one by one: all_AP.get(i);
			// list_sensors_testview.setText("estimate " + i);

			// choose the measurement within each AP whose size is the biggest
			int id_with_the_biggest_size = 0;
			int _temp_size = 0;
			for (int j = 0; j < all_AP.get(i).list_all_nodes.size(); j++) {
				if (all_AP.get(i).list_all_nodes.get(j).list_all_nodes_each_time
						.size() > _temp_size) {
					id_with_the_biggest_size = j;
					_temp_size = all_AP.get(i).list_all_nodes.get(j).list_all_nodes_each_time
							.size();
				}
			}

			// Log.d("estimate_location", id_with_the_biggest_size +
			// " has the biggest size = " +
			// all_AP.get(i).list_all_nodes.get(id_with_the_biggest_size).list_all_nodes_each_time.size());
			// initialize the combined_result with [id_with_the_biggest_size]
			// store the combined results of 3 measurements
			List<AP_Property_oneTime_each_node> combined_result = new ArrayList<AP_Property_oneTime_each_node>(
					all_AP.get(i).list_all_nodes.get(id_with_the_biggest_size).list_all_nodes_each_time);

			// combine other measurements into combined_result
			for (int k = 0; k < all_AP.get(i).list_all_nodes.size(); k++) {
				if (k == id_with_the_biggest_size) {
					continue;
				}
				for (int l = 0; l < all_AP.get(i).list_all_nodes.get(k).list_all_nodes_each_time
						.size(); l++) {
					int found_ID = contains_BSSID(
							combined_result,
							all_AP.get(i).list_all_nodes.get(k).list_all_nodes_each_time
									.get(l)._BSSID);
					if (found_ID != -1) {
						// already have the BSSID in combined_result just add
						// the value;
						combined_result.get(found_ID)._level += all_AP.get(i).list_all_nodes
								.get(k).list_all_nodes_each_time.get(l)._level;
						combined_result.get(found_ID)._valid_time += all_AP
								.get(i).list_all_nodes.get(k).list_all_nodes_each_time
								.get(l)._valid_time;
					} else {
						// else not found, just add it to combined result
						combined_result
								.add(all_AP.get(i).list_all_nodes.get(k).list_all_nodes_each_time
										.get(l));
					}
				}
			}

			// test code
			// print_list(combined_result);

			// list_sensors_testview.setText("size " + _temp_each_m.size());

			// calculate the distance and store the result to ap_distance
			long total_distance = 0;
			for (int m = 0; m < _temp_each_m.size(); m++) {
				int found_ID = contains_BSSID(combined_result,
						_temp_each_m.get(m)._BSSID);
				if (found_ID != -1) {
					// found
					total_distance += Math
							.pow((combined_result.get(found_ID)._level
									/ combined_result.get(found_ID)._valid_time - _temp_each_m
									.get(m)._level
									/ _temp_each_m.get(m)._valid_time), 2);
				} else {
					// not found
					total_distance += Math.pow(
							(-99 - _temp_each_m.get(m)._level
									/ _temp_each_m.get(m)._valid_time), 2);
				}
			}
			AP_Distance _temp_distance = new AP_Distance();
			_temp_distance.AP_Name = all_AP.get(i).AP_Name;
			_temp_distance.distance = total_distance;
			ap_distance.add(_temp_distance);
			Log.d("estimate_distance", "total_distance for " + i + " = "
					+ total_distance);
		}

		// search for the near location
		int near_location_id = -1;
		long _temp_distance = -1;
		Log.d("debug", "size of ap_distance " + ap_distance.size());
		if (ap_distance.size() > 0) {
			_temp_distance = ap_distance.get(0).distance;
			near_location_id = 0;
		}

		// list_sensors_testview.setText("Distance:" +
		// ap_distance.get(0).distance + "*" + ap_distance.get(2).distance);

		for (int i = 0; i < ap_distance.size(); i++) {
			if (ap_distance.get(i).distance < _temp_distance) {
				near_location_id = i;
				_temp_distance = ap_distance.get(i).distance;
			}
		}

		// Log.d("location result", "nearest place is " +
		// ap_distance.get(near_location_id).AP_Name + " with a distance = " +
		// ap_distance.get(near_location_id).distance);
		// console_view.setText("nearest place is " +
		// ap_distance.get(near_location_id).AP_Name);
		// list_sensors_testview.setText("size " + near_location_id);
		if (ap_distance.size() > 0 && near_location_id > -1) {
			return ap_distance.get(near_location_id).AP_Name;
		} else {
			return "not found!";
		}
	}

	public void estimate_m_data_func(View view) throws JSONException {

		TextView console_view = (TextView) findViewById(R.id.console_panel);
		console_view.setText("Estimating...please wait....");
		console_view.setText("nearest place is "
				+ estimate_location(
						"random_location2/A150/result_20141105_180149.json",
						"assets"));

	}

	public void locate_myself_func(View view) {
		TextView console_view = (TextView) findViewById(R.id.console_panel);
		TextView list_sensors_testview = (TextView) findViewById(R.id.list_sensors_testview);
		console_view.setText("Locating...please wait....");
		// collect wifi_fingerprint and store it to tmp/local.json
		// collect wifi_fingerprint
		myWifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		registerReceiver(myWifiScanReceiver, new IntentFilter(
				WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
		List<ScanResult> wifi_scan_result = myWifiManager.getScanResults();
		JSONObject measurement_object = new JSONObject();
		for (int i = 0; i < wifi_scan_result.size(); i++) {
			JSONObject each_ap = new JSONObject();
			try {
				each_ap.put("BSSID", wifi_scan_result.get(i).BSSID.toString());
				each_ap.put("level", wifi_scan_result.get(i).level);
				measurement_object.put("ap" + (i + 1), each_ap);

				// list_sensors_testview.setText(each_ap.getString("BSSID") +
				// " " + each_ap.getString("level"));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		// test code;
		Log.d("locate_myself",
				"size of current wifi ap:" + measurement_object.length());
		// list_sensors_testview.setText("size of current wifi ap:" +
		// measurement_object.length());

		// store it to local.json
		// read former local.json
		String filePath = getFilesDir() + "/local.json";

		Log.d("locate_myself", filePath);

		// check whether file is valid
		File check_file = new File(filePath);
		if (check_file == null || check_file.exists() == false) {
			try {
				check_file.createNewFile();
				Log.d("locate_myself", "file not found, create one");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Log.d("locate_myself", "file found");
		}

		// read local.json
		String my_json_string = null;
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;

		try {
			InputStreamReader jsonInput = new InputStreamReader(
					new FileInputStream(new File(filePath)));

			br = new BufferedReader(jsonInput);
			String temp;
			int _temp_count = 0;
			while ((temp = br.readLine()) != null) {
				sb.append(temp);
				_temp_count++;
			}
			if (_temp_count == 0) {
				Log.d("locate", "local.json is empty");
				// list_sensors_testview.setText("local.json is empty");
			} else {
				my_json_string = sb.toString();
				Log.d("locate_myself", "my_json_string" + my_json_string);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// add measurement data
		try {
			JSONObject jsonObjMain = null;
			if (my_json_string == null) {
				jsonObjMain = new JSONObject();
			} else {
				jsonObjMain = new JSONObject(my_json_string);
			}
			// add the current collected data to filePath
			jsonObjMain.put("measurement " + (jsonObjMain.length() + 1),
					measurement_object);

			// write back
			try {
				FileWriter write_file = new FileWriter(filePath);
				if (jsonObjMain != null) {
					write_file.write(jsonObjMain.toString());

					// list_sensors_testview.setText("json_main:" +
					// jsonObjMain.length() + " measurement:" +
					// measurement_object.length() + jsonObjMain.toString());

				}
				write_file.flush();
				write_file.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Log.d("jsonObjMain", "size of jsonObjMain " + jsonObjMain.length());

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// estimate location using local.json file
		try {
			console_view.setText("The nearest location is "
					+ estimate_location("local.json", "local.json"));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clean_location_func(View view) {
		// clean local.json
		TextView console_view = (TextView) findViewById(R.id.console_panel);
		console_view.setText("Clean location...please wait....");
		String filePath = getFilesDir() + "/local.json";
		File _delete_json = new File(filePath);
		_delete_json.delete();
		try {
			_delete_json.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		_delete_json = null;
		console_view.setText("Clean location done");
	}

	public void measure_distance_func(View view) {
		Intent intent = new Intent(this, Measure_distance.class);
		startActivity(intent);
	}

}
