package com.example.playground;

import java.util.List;

public class AP_Property_multiple_time {
	List<AP_Property_each_time_all_nodes> list_all_nodes;
	String AP_Name;
}
